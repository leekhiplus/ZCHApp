package com.zch.newscard

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.OutputStream

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        fileCb?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        fileCb = null
    }

    private val saver by lazy { Saver(this) }
    private val exporter by lazy { VideoExporter(this) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    view: WebView,
                    callback: ValueCallback<Array<Uri>>,
                    params: FileChooserParams
                ): Boolean {
                    fileCb?.onReceiveValue(null)
                    fileCb = callback
                    picker.launch(params.acceptTypes.firstOrNull { it.contains('/') } ?: "*/*")
                    return true
                }
            }
            addJavascriptInterface(Bridge(), "ZCH")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    /** Methods called from JavaScript as window.ZCH.* */
    inner class Bridge {
        @JavascriptInterface
        fun begin(name: String, mime: String): Boolean = saver.begin(name, mime)

        @JavascriptInterface
        fun chunk(base64: String): Boolean = saver.chunk(base64)

        @JavascriptInterface
        fun end(): String = saver.end()

        @JavascriptInterface
        fun encStart(width: Int, height: Int, fps: Int, bitrate: Int, fileName: String): Boolean =
            exporter.start(width, height, fps, bitrate, fileName)

        @JavascriptInterface
        fun encFrame(jpegBase64: String): Boolean =
            exporter.frame(Base64.decode(jpegBase64, Base64.DEFAULT))

        @JavascriptInterface
        fun encEnd(): String = exporter.finish(saver)

        @JavascriptInterface
        fun encCancel() = exporter.cancel()

        @JavascriptInterface
        fun audioBegin(): Boolean = exporter.voiceBegin()

        @JavascriptInterface
        fun audioChunk(base64: String): Boolean = exporter.voiceChunk(base64)

        @JavascriptInterface
        fun audioEnd(): Boolean = exporter.voiceEnd()
    }
}

/**
 * Saves files into the public Downloads folder so they show up in the phone's Files app.
 * Android 10+ uses MediaStore (no permission needed); older versions write directly.
 */
class Saver(private val ctx: Context) {
    private var out: OutputStream? = null
    private var uri: Uri? = null
    private var file: File? = null
    private var name = ""

    fun begin(fileName: String, mime: String): Boolean {
        end()
        name = fileName
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                uri = u
                out = ctx.contentResolver.openOutputStream(u)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                val f = File(dir, fileName)
                file = f
                out = f.outputStream()
            }
            out != null
        } catch (e: Exception) {
            false
        }
    }

    fun chunk(base64: String): Boolean {
        val o = out ?: return false
        return try {
            o.write(Base64.decode(base64, Base64.DEFAULT))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun end(): String {
        var msg = "Saved to Downloads: $name"
        try {
            out?.close()
            uri?.let { u ->
                ctx.contentResolver.update(
                    u,
                    ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) },
                    null,
                    null
                )
            }
        } catch (e: Exception) {
            msg = "Could not save the file. Check free storage and try again."
        }
        out = null
        uri = null
        file = null
        return msg
    }

    fun copyFile(src: File, fileName: String, mime: String): String {
        if (!begin(fileName, mime)) return "Could not create the file in Downloads."
        return try {
            src.inputStream().use { input -> input.copyTo(out!!) }
            end()
        } catch (e: Exception) {
            end()
            "Could not save the file. Check free storage and try again."
        }
    }
}
