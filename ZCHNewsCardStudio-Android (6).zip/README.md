# ZCH NewsCard Studio (Android)

Android app (WebView) that runs the offline Urdu news-card and video editor in `app/src/main/assets/index.html`.

## Build the APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this ZIP to the repository root (not inside a folder).
2. Open the **Actions** tab, choose **Android Build** and press **Run workflow** (it also runs on every push to `main`).
3. When it finishes, open the run and download the artifact **ZCH-NewsCard-Studio-debug-apk**, unzip it and install `app-debug.apk`.

No Gradle wrapper is included: the workflow installs Gradle 8.9 itself. To build in Android Studio, open the folder and let it sync.

## Notes
- Exported videos are saved to `Movies/ZCH NewsCard Studio/` (MP4 when the phone's WebView supports it, otherwise WebM).
- Export records in real time. Keep the app open on screen until it finishes.
- Fonts other than the system ones load from Google Fonts when the phone is online. Voiceover, images and projects stay on the phone.
- Edit `index.html` in `app/src/main/assets/` to change the editor itself.
