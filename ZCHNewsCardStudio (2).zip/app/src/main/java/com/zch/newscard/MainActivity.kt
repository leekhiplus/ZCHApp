package com.zch.newscard

import android.annotation.SuppressLint
import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import java.io.File
import java.io.OutputStream

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    // Modern photo picker for images (no storage permission needed)
    private val imagePicker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { deliver(it) }
    // Generic picker for audio and fonts
    private val filePicker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { deliver(it) }

    // Serves files from app/src/main/assets under a secure https origin
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val saver by lazy { Saver(this) }
    private val exporter by lazy { VideoExporter(this) }

    private fun deliver(uris: List<Uri>) {
        fileCb?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        fileCb = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClientCompat() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    assetLoader.shouldInterceptRequest(request.url)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    view: WebView,
                    callback: ValueCallback<Array<Uri>>,
                    params: FileChooserParams
                ): Boolean {
                    fileCb?.onReceiveValue(null)
                    fileCb = callback
                    val accept = params.acceptTypes.firstOrNull { it.contains('/') } ?: "*/*"
                    if (accept.startsWith("image/")) {
                        imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    } else {
                        filePicker.launch(accept)
                    }
                    return true
                }
            }
            addJavascriptInterface(Bridge(), "ZCH")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    /** Methods called from JavaScript as window.ZCH.* */
    inner class Bridge {
        @JavascriptInterface
        fun begin(name: String, mime: String): Boolean = saver.begin(name, mime)

        @JavascriptInterface
        fun chunk(base64: String): Boolean = saver.chunk(base64)

        @JavascriptInterface
        fun end(): String = saver.end()

        @JavascriptInterface
        fun encStart(width: Int, height: Int, fps: Int, bitrate: Int, fileName: String): Boolean =
            exporter.start(width, height, fps, bitrate, fileName)

        @JavascriptInterface
        fun encFrame(jpegBase64: String): Boolean =
            exporter.frame(Base64.decode(jpegBase64, Base64.DEFAULT))

        @JavascriptInterface
        fun encEnd(): String = exporter.finish(saver)

        @JavascriptInterface
        fun encCancel() = exporter.cancel()

        @JavascriptInterface
        fun audioBegin(): Boolean = exporter.voiceBegin()

        @JavascriptInterface
        fun audioChunk(base64: String): Boolean = exporter.voiceChunk(base64)

        @JavascriptInterface
        fun audioEnd(): Boolean = exporter.voiceEnd()

        /** Keeps the screen on while rendering, so Android does not pause the export. */
        @JavascriptInterface
        fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    ExportService.start(this@MainActivity)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    ExportService.stop(this@MainActivity)
                }
            }
        }

        /** Updates the percentage shown in the export notification. */
        @JavascriptInterface
        fun setProgress(percent: Int) {
            ExportService.progress(this@MainActivity, percent)
        }

        /** Opens the Android share sheet for the last saved video (Android 10+). */
        @JavascriptInterface
        fun share(): Boolean {
            val u = saver.lastUri() ?: return false
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, u)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "Share video"))
            }
            return true
        }
    }
}

/**
 * Saves files into the public Downloads folder so they show up in the phone's Files app.
 * Android 10+ uses MediaStore (no permission needed); older versions write directly.
 */
class Saver(private val ctx: Context) {
    private var out: OutputStream? = null
    private var uri: Uri? = null
    private var last: Uri? = null
    private var file: File? = null
    private var name = ""

    fun lastUri(): Uri? = last

    fun begin(fileName: String, mime: String): Boolean {
        end()
        name = fileName
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                uri = u
                out = ctx.contentResolver.openOutputStream(u)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                val f = File(dir, fileName)
                file = f
                out = f.outputStream()
            }
            out != null
        } catch (e: Exception) {
            false
        }
    }

    fun chunk(base64: String): Boolean {
        val o = out ?: return false
        return try {
            o.write(Base64.decode(base64, Base64.DEFAULT))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun end(): String {
        var msg = "Saved to Downloads: $name"
        try {
            out?.close()
            uri?.let { u ->
                ctx.contentResolver.update(
                    u,
                    ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) },
                    null,
                    null
                )
                last = u
            }
        } catch (e: Exception) {
            msg = "Could not save the file. Check free storage and try again."
        }
        out = null
        uri = null
        file = null
        return msg
    }

    fun copyFile(src: File, fileName: String, mime: String): String {
        if (!begin(fileName, mime)) return "Could not create the file in Downloads."
        return try {
            src.inputStream().use { input -> input.copyTo(out!!) }
            end()
        } catch (e: Exception) {
            end()
            "Could not save the file. Check free storage and try again."
        }
    }
}
