package com.zch.newscard

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Adds the voiceover to the exported video.
 * 1. Voiceover (Gemini WAV, or MP3/M4A/AAC from an import) -> raw 16-bit PCM
 * 2. PCM -> AAC (.m4a)
 * 3. Video track + AAC track -> one MP4, copied sample by sample in time order
 */
object AudioMux {

    /** Returns true when the mixed file was written. */
    fun mixVoice(dir: File, voice: File, video: File, out: File, videoDurUs: Long): Boolean {
        val pcm = File(dir, "voice.pcm")
        val aac = File(dir, "voice.m4a")
        return try {
            val fmt = toPcm(voice, pcm) ?: return false
            if (!pcmToAac(pcm, fmt.first, fmt.second, aac)) return false
            merge(video, aac, out, videoDurUs)
        } catch (e: Exception) {
            false
        } finally {
            pcm.delete()
            aac.delete()
        }
    }

    /** Returns (sampleRate, channels) of the PCM written to pcmOut. */
    private fun toPcm(src: File, pcmOut: File): Pair<Int, Int>? {
        val bytes = src.readBytes()
        return if (bytes.size > 12 && String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF") {
            wavToPcm(bytes, pcmOut)
        } else {
            compressedToPcm(src, pcmOut)
        }
    }

    private fun wavToPcm(b: ByteArray, pcmOut: File): Pair<Int, Int>? {
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        var off = 12
        var rate = 0
        var ch = 0
        var bits = 0
        while (off + 8 <= b.size) {
            val id = String(b, off, 4, Charsets.US_ASCII)
            val size = bb.getInt(off + 4)
            if (size < 0) return null
            val body = off + 8
            if (id == "fmt ") {
                ch = bb.getShort(body + 2).toInt()
                rate = bb.getInt(body + 4)
                bits = bb.getShort(body + 14).toInt()
            } else if (id == "data") {
                if (bits != 16 || rate <= 0 || ch <= 0) return null
                val end = minOf(b.size, body + size)
                FileOutputStream(pcmOut).use { it.write(b, body, end - body) }
                return Pair(rate, ch)
            }
            off = body + size + (size and 1)
        }
        return null
    }

    private fun compressedToPcm(src: File, pcmOut: File): Pair<Int, Int>? {
        val ex = MediaExtractor()
        ex.setDataSource(src.absolutePath)
        val ti = track(ex, "audio/")
        if (ti < 0) {
            ex.release()
            return null
        }
        ex.selectTrack(ti)
        val inFmt = ex.getTrackFormat(ti)
        // Ask the decoder for 16-bit output so the PCM file is always 16-bit
        inFmt.setInteger(MediaFormat.KEY_PCM_ENCODING, android.media.AudioFormat.ENCODING_PCM_16BIT)
        val dec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
        dec.configure(inFmt, null, null, 0)
        dec.start()

        var rate = inFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = inFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val info = MediaCodec.BufferInfo()
        var inEos = false
        var outEos = false

        FileOutputStream(pcmOut).use { fos ->
            while (!outEos) {
                if (!inEos) {
                    val i = dec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = dec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inEos = true
                        } else {
                            dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = dec.dequeueOutputBuffer(info, 10_000)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = dec.outputFormat
                    rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (o >= 0) {
                    val buf = dec.getOutputBuffer(o)
                    if (buf != null && info.size > 0) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val arr = ByteArray(info.size)
                        buf.get(arr)
                        fos.write(arr)
                    }
                    dec.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outEos = true
                }
            }
        }
        dec.stop()
        dec.release()
        ex.release()
        return Pair(rate, ch)
    }

    private fun pcmToAac(pcm: File, rate: Int, ch: Int, out: File): Boolean {
        val format = MediaFormat.createAudioFormat("audio/mp4a-latm", rate, ch).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 64000 * ch)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val enc = MediaCodec.createEncoderByType("audio/mp4a-latm")
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        var samples = 0L
        var done = false
        var inputDone = false
        val frameBytes = 2 * ch
        val chunk = ByteArray(16384 / frameBytes * frameBytes)
        val info = MediaCodec.BufferInfo()

        pcm.inputStream().use { input ->
            while (!done) {
                if (!inputDone) {
                    val i = enc.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val n = input.read(chunk)
                        val buf = enc.getInputBuffer(i)!!
                        buf.clear()
                        val pts = samples * 1_000_000L / rate
                        if (n <= 0) {
                            enc.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            buf.put(chunk, 0, n)
                            enc.queueInputBuffer(i, 0, n, pts, 0)
                            samples += n / frameBytes
                        }
                    }
                }
                val o = enc.dequeueOutputBuffer(info, 10_000)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(enc.outputFormat)
                    muxer.start()
                    started = true
                } else if (o >= 0) {
                    val buf = enc.getOutputBuffer(o)
                    if (started && buf != null && info.size > 0 &&
                        (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                    ) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        muxer.writeSampleData(track, buf, info)
                    }
                    enc.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) done = true
                }
            }
        }
        enc.stop()
        enc.release()
        muxer.stop()
        muxer.release()
        return true
    }

    /** Copies samples from the video and audio files in time order into one MP4. */
    private fun merge(video: File, audio: File, out: File, videoDurUs: Long): Boolean {
        val ve = MediaExtractor()
        val ae = MediaExtractor()
        ve.setDataSource(video.absolutePath)
        ae.setDataSource(audio.absolutePath)
        val vt = track(ve, "video/")
        val at = track(ae, "audio/")
        if (vt < 0 || at < 0) {
            ve.release()
            ae.release()
            return false
        }
        ve.selectTrack(vt)
        ae.selectTrack(at)

        val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val vi = mux.addTrack(ve.getTrackFormat(vt))
        val ai = mux.addTrack(ae.getTrackFormat(at))
        mux.start()

        val buf = ByteBuffer.allocate(1 shl 20)
        val info = MediaCodec.BufferInfo()
        var vTime = ve.sampleTime
        var aTime = ae.sampleTime

        // Audio beyond the end of the video is dropped
        while (vTime >= 0 || (aTime >= 0 && aTime <= videoDurUs)) {
            val useVideo = vTime >= 0 && (aTime < 0 || aTime > videoDurUs || vTime <= aTime)
            val ex = if (useVideo) ve else ae
            buf.clear()
            val size = ex.readSampleData(buf, 0)
            if (size >= 0) {
                buf.position(0)
                buf.limit(size)
                info.offset = 0
                info.size = size
                info.presentationTimeUs = ex.sampleTime
                info.flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                    MediaCodec.BUFFER_FLAG_KEY_FRAME
                } else {
                    0
                }
                mux.writeSampleData(if (useVideo) vi else ai, buf, info)
            }
            ex.advance()
            if (useVideo) vTime = ve.sampleTime else aTime = ae.sampleTime
        }

        mux.stop()
        mux.release()
        ve.release()
        ae.release()
        return true
    }

    private fun track(e: MediaExtractor, prefix: String): Int {
        for (i in 0 until e.trackCount) {
            val mime = e.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }
}
