package com.zafarcrickethub.zchnewscardstudio

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var out: OutputStream? = null
    private var pending: Uri? = null
    private var label = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "ZCH")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = callback
                return try {
                    startActivityForResult(params.createIntent(), 1)
                    true
                } catch (e: Exception) {
                    chooser = null
                    false
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooser = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript(
            "(function(){if(CT>0){tab(0);return 1}return 0})()"
        ) { if (it != "1") finish() }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    /** Saves exported videos/images in Movies or Pictures / ZCH NewsCard Studio. */
    inner class Bridge {
        @Synchronized
        @JavascriptInterface
        fun begin(name: String, mime: String): Boolean {
            return try {
                val video = mime.startsWith("video")
                val dir = if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues()
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/ZCH NewsCard Studio")
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1)
                    val coll = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    pending = contentResolver.insert(coll, v)
                    out = pending?.let { contentResolver.openOutputStream(it) }
                    label = "$dir/ZCH NewsCard Studio/$name"
                } else {
                    val f = File(getExternalFilesDir(dir), name)
                    out = FileOutputStream(f)
                    label = f.absolutePath
                }
                out != null
            } catch (e: Exception) {
                false
            }
        }

        @Synchronized
        @JavascriptInterface
        fun chunk(b64: String): Boolean {
            return try {
                out?.write(Base64.decode(b64, Base64.DEFAULT))
                true
            } catch (e: Exception) {
                false
            }
        }

        @Synchronized
        @JavascriptInterface
        fun end(): String {
            return try {
                out?.flush()
                out?.close()
                out = null
                pending?.let {
                    val v = ContentValues()
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    contentResolver.update(it, v, null, null)
                }
                pending = null
                "Saved to $label"
            } catch (e: Exception) {
                "Could not finish saving the file."
            }
        }
    }
}
