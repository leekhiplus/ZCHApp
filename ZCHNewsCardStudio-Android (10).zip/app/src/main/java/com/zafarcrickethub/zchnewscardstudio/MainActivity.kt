package com.zafarcrickethub.zchnewscardstudio

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var out: OutputStream? = null
    private var pending: Uri? = null
    private var label = ""
    private var pickKey = "img"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "ZCH")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = callback
                return try {
                    startActivityForResult(params.createIntent(), 1)
                    true
                } catch (e: Exception) {
                    chooser = null
                    false
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun jsWait(code: String) {
        val latch = java.util.concurrent.CountDownLatch(1)
        runOnUiThread { web.evaluateJavascript(code) { latch.countDown() } }
        latch.await(10, java.util.concurrent.TimeUnit.SECONDS)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            1 -> {
                chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                chooser = null
            }
            2 -> {
                val uris = ArrayList<Uri>()
                if (resultCode == RESULT_OK && data != null) {
                    val cd = data.clipData
                    if (cd != null) {
                        for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
                    } else {
                        val u = data.data
                        if (u != null) uris.add(u)
                    }
                }
                val key = pickKey
                Thread {
                    js("nativeBusy(" + uris.size + ")")
                    for (u in uris) {
                        val s = decode(u, if (key == "logo") 600 else 1280, key == "logo")
                        if (s != null) js("nativeImg('" + key + "'," + JSONObject.quote(s) + ")")
                        else js("nativeErr()")
                    }
                    js("nativeDone()")
                }.start()
            }
            3 -> {
                val u = if (resultCode == RESULT_OK) data?.data else null
                if (u != null) {
                    Thread {
                        try {
                            val mime = contentResolver.getType(u) ?: "audio/mpeg"
                            var name = "voice"
                            contentResolver.query(u, null, null, null, null)?.use { c ->
                                if (c.moveToFirst()) {
                                    val ix = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                                    if (ix >= 0) name = c.getString(ix)
                                }
                            }
                            jsWait("nativeAudStart()")
                            contentResolver.openInputStream(u)?.use { st ->
                                val buf = ByteArray(393216)
                                while (true) {
                                    val n = st.read(buf)
                                    if (n <= 0) break
                                    jsWait("nativeAudChunk('" + Base64.encodeToString(buf, 0, n, Base64.NO_WRAP) + "')")
                                }
                            }
                            jsWait("nativeAudDone(" + JSONObject.quote(name) + "," + JSONObject.quote(mime) + ")")
                        } catch (e: Exception) {
                            js("nativeErr()")
                        }
                    }.start()
                }
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    /** Decodes a picked image, applies EXIF rotation, shrinks it and returns a data URL. */
    private fun decode(u: Uri, max: Int, png: Boolean): String? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var sample = 1
            while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= max) sample *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sample
            var bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val deg = try {
                contentResolver.openInputStream(u)?.use {
                    when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                        6 -> 90
                        3 -> 180
                        8 -> 270
                        else -> 0
                    }
                } ?: 0
            } catch (e: Exception) {
                0
            }
            val m = maxOf(bmp.width, bmp.height)
            val f = if (m > max) max.toFloat() / m else 1f
            if (deg != 0 || f < 1f) {
                val mx = Matrix()
                mx.postScale(f, f)
                mx.postRotate(deg.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
            }
            val bo = ByteArrayOutputStream()
            if (png) bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
            else bmp.compress(Bitmap.CompressFormat.JPEG, 85, bo)
            "data:" + (if (png) "image/png" else "image/jpeg") + ";base64," +
                Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
        } catch (e: Throwable) {
            null
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript(
            "(function(){if(CT>0){tab(0);return 1}return 0})()"
        ) { if (it != "1") finish() }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    inner class Bridge {
        /** Opens the system image picker; the page receives the decoded images. */
        @JavascriptInterface
        fun pick(key: String, multiple: Boolean) {
            runOnUiThread {
                pickKey = key
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.type = "image/*"
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
                try {
                    startActivityForResult(i, 2)
                } catch (e: Exception) {
                    js("nativeErr()")
                }
            }
        }

        /** Opens the system audio picker; the page receives the file in chunks. */
        @JavascriptInterface
        fun pickAudio() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.type = "audio/*"
                i.addCategory(Intent.CATEGORY_OPENABLE)
                try {
                    startActivityForResult(i, 3)
                } catch (e: Exception) {
                    js("nativeErr()")
                }
            }
        }

        @Synchronized
        @JavascriptInterface
        fun begin(name: String, mime: String): Boolean {
            return try {
                val video = mime.startsWith("video")
                val dir = if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues()
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/ZCH NewsCard Studio")
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1)
                    val coll = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    pending = contentResolver.insert(coll, v)
                    out = pending?.let { contentResolver.openOutputStream(it) }
                    label = "$dir/ZCH NewsCard Studio/$name"
                } else {
                    val f = File(getExternalFilesDir(dir), name)
                    out = FileOutputStream(f)
                    label = f.absolutePath
                }
                out != null
            } catch (e: Exception) {
                false
            }
        }

        @Synchronized
        @JavascriptInterface
        fun chunk(b64: String): Boolean {
            return try {
                out?.write(Base64.decode(b64, Base64.DEFAULT))
                true
            } catch (e: Exception) {
                false
            }
        }

        @Synchronized
        @JavascriptInterface
        fun end(): String {
            return try {
                out?.flush()
                out?.close()
                out = null
                pending?.let {
                    val v = ContentValues()
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    contentResolver.update(it, v, null, null)
                }
                pending = null
                "Saved to $label"
            } catch (e: Exception) {
                "Could not finish saving the file."
            }
        }
    }
}
